package com.ignaciocanay.firebase.fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.findNavController
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.ignaciocanay.firebase.R
import com.ignaciocanay.firebase.viewmodels.LivingViewModel

class Living : Fragment() {
lateinit var v : View
lateinit var botonACocina : Button
lateinit var botonAHabitacion :Button
lateinit var botonled3 : Button
private lateinit var database: DatabaseReference
lateinit var txtEstadoLed3 : TextView
lateinit var estadoLedPedazo3 : String
var led3 = ""
    companion object {
        fun newInstance() = Living()
    }

    private lateinit var viewModel: LivingViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v = inflater.inflate(R.layout.fragment_living, container, false)

        botonACocina = v.findViewById(R.id.botonACocina)
        botonAHabitacion = v.findViewById(R.id.botonAHAbitacion)
        botonled3 = v.findViewById(R.id.buttonLed3)
        txtEstadoLed3 = v.findViewById(R.id.pedazoDeTexto3)
        return v
    }
    override fun onStart() {
        super.onStart()
        database = Firebase.database.getReference("led3")
        database.get().addOnSuccessListener {
            led3 = it.value.toString()

            if (led3 == "true") {

                estadoLedPedazo3 = "ON"
                txtEstadoLed3.text = estadoLedPedazo3
            } else {

                estadoLedPedazo3 = "OFF"
                txtEstadoLed3.text = estadoLedPedazo3
            }
        }



          botonAHabitacion.setOnClickListener(){
              val action = LivingDirections.actionLivingToHabitacion()
              v.findNavController().navigate(action)
          }
        botonACocina.setOnClickListener(){
            val action = LivingDirections.actionLivingToCocina()
            v.findNavController().navigate(action)
        }
        botonled3.setOnClickListener() {
            database = Firebase.database.getReference("led3")

            database.get().addOnSuccessListener {
                led3 = it.value.toString()
            }
            if (led3 == "true") {
                estadoLedPedazo3 = "OFF"
                txtEstadoLed3.text = estadoLedPedazo3
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("led3")
                myRef.setValue(false)
            } else {
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("led3")
                myRef.setValue(true)
                estadoLedPedazo3 = "ON"
                txtEstadoLed3.text = estadoLedPedazo3
            }
        }
    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(LivingViewModel::class.java)
        // TODO: Use the ViewModel
    }

}