package com.ignaciocanay.firebase.fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.findNavController
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.ignaciocanay.firebase.R
import com.ignaciocanay.firebase.viewmodels.CocinaViewModel
import java.util.jar.Pack200

class cocina : Fragment() {
    lateinit var botonAHabitacion : Button
    lateinit var botonled : Button
    lateinit var botonmot1 : Button
    lateinit var botonled2 : Button
    lateinit var botonmot2 : Button
    lateinit var txtEstadoLed : TextView
    lateinit var txtEstadoLed2 : TextView
    private lateinit var database: DatabaseReference
    lateinit var estadoLedPedazo : String
    lateinit var estadoLedPedazo2 : String
    lateinit var v : View
    lateinit var botonALiving : Button


    var led = ""
    var led1 = ""

    companion object {
        fun newInstance() = cocina()
    }

    private lateinit var viewModel: CocinaViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        v = inflater.inflate(R.layout.fragment_cocina, container, false)
        txtEstadoLed = v.findViewById(R.id.pedazoDeTexto1)
        txtEstadoLed2 = v.findViewById(R.id.pedazoDeTexto2)

      botonAHabitacion = v.findViewById(R.id.buttonHabitacionACocina)
        botonled = v.findViewById(R.id.buttonLed1)
        botonALiving = v.findViewById(R.id.ButtonALiving)
        botonled2 = v.findViewById(R.id.buttonLed2)

        return v
    }

    override fun onStart() {
        super.onStart()
        database = Firebase.database.getReference("led")
        database.get().addOnSuccessListener {
            led = it.value.toString()

            if (led == "true") {

                estadoLedPedazo = "ON"
                txtEstadoLed.text = estadoLedPedazo
            } else {

                estadoLedPedazo = "OFF"
                txtEstadoLed.text = estadoLedPedazo
            }
        }
        database = Firebase.database.getReference("led1")
        database.get().addOnSuccessListener {
            led1 = it.value.toString()

            if (led1 == "true") {

                estadoLedPedazo2 = "ON"
                txtEstadoLed2.text = estadoLedPedazo2
            } else {

                estadoLedPedazo2 = "OFF"
                txtEstadoLed2.text = estadoLedPedazo2
            }
        }



        botonAHabitacion.setOnClickListener() {
            val action = cocinaDirections.actionCocinaToHabitacion()
            v.findNavController().navigate(action)
        }
        botonALiving.setOnClickListener(){
            val action = cocinaDirections.actionCocinaToLiving()
            v.findNavController().navigate(action)
        }
        botonled.setOnClickListener() {
            database = Firebase.database.getReference("led")

            database.get().addOnSuccessListener {
                led = it.value.toString()
            }
            if (led == "true") {
                estadoLedPedazo = "OFF"
                txtEstadoLed.text = estadoLedPedazo
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("led")
                myRef.setValue(false)
            } else {
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("led")
                myRef.setValue(true)
                estadoLedPedazo = "ON"
                txtEstadoLed.text = estadoLedPedazo
            }
        }
        botonled2.setOnClickListener() {
            database = Firebase.database.getReference("led1")

            database.get().addOnSuccessListener {
                led1 = it.value.toString()
            }
            if (led1 == "true") {
                estadoLedPedazo2 = "OFF"
                txtEstadoLed2.text = estadoLedPedazo2
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("led1")
                myRef.setValue(false)
            } else {
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("led1")
                myRef.setValue(true)
                estadoLedPedazo2 = "ON"
                txtEstadoLed2.text = estadoLedPedazo2
            }
        }
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(CocinaViewModel::class.java)


    }

}