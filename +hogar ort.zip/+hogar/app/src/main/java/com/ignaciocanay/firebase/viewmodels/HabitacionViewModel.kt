package com.ignaciocanay.firebase.viewmodels

import androidx.lifecycle.ViewModel

class HabitacionViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}