package com.ignaciocanay.firebase.fragments

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.navigation.findNavController
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import com.ignaciocanay.firebase.R
import com.ignaciocanay.firebase.viewmodels.HabitacionViewModel

class habitacion : Fragment() {
    lateinit var v : View
    private lateinit var database: DatabaseReference
    private lateinit var database1: DatabaseReference
    private lateinit var database2: DatabaseReference
    lateinit var botonPersianaHabitacionSube  : Button
    lateinit var botonPersianaHabitacionBaja  : Button
    lateinit var botonVentiladorHabitacion  : Button
    lateinit var txtEstadoPersiana : TextView
    lateinit var txtEstadoVentilador : TextView
    lateinit var estadoVentiladorPedazo : String
    lateinit var estadoPersianaPedazo : String
    lateinit var BotonCocina : Button
    lateinit var BotonALiving : Button

    var estadoPersiana : Boolean = false
    var PersianaSubiendo = ""
    var PersianaBajando = ""
    var Ventilador = ""

    companion object {
        fun newInstance() = habitacion()
    }

    private lateinit var viewModel: HabitacionViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        v = inflater.inflate(R.layout.fragment_habitacion, container, false)
        botonVentiladorHabitacion = v.findViewById(R.id.botonVentilador)
        botonPersianaHabitacionSube = v.findViewById(R.id.botonPersiana)
        BotonCocina = v.findViewById(R.id.buttonCocina)
        BotonALiving = v.findViewById(R.id.botonaLIVING)
        txtEstadoPersiana = v.findViewById(R.id.pedazoDeTexto5)
        txtEstadoVentilador = v.findViewById(R.id.pedazoDeTexto4)
        return v

    }

    override fun onStart() {
        super.onStart()
        database = Firebase.database.getReference("ventilador")
        database.get().addOnSuccessListener {
            Ventilador = it.value.toString()

            if (Ventilador == "true") {

                estadoVentiladorPedazo = "ON"
                txtEstadoVentilador.text = estadoVentiladorPedazo
            } else {

                estadoVentiladorPedazo = "OFF"
                txtEstadoVentilador.text = estadoVentiladorPedazo
            }
        }

        database = Firebase.database.getReference("estadopersiana")
        database.get().addOnSuccessListener {
            PersianaSubiendo = it.value.toString()

            if (PersianaSubiendo == "true") {
                estadoPersianaPedazo = "Arriba"
                txtEstadoPersiana.text = estadoPersianaPedazo
                estadoPersiana = true
            } else {
                estadoPersianaPedazo = "Abajo"
                txtEstadoPersiana.text = estadoPersianaPedazo
                estadoPersiana = false
            }
        }



        BotonCocina.setOnClickListener() {
            val action = habitacionDirections.actionHabitacionToCocina()
            v.findNavController().navigate(action)
        }
        BotonALiving.setOnClickListener(){
            val action = habitacionDirections.actionHabitacionToLiving()
            v.findNavController().navigate(action)
        }
        botonVentiladorHabitacion.setOnClickListener() {
            database = Firebase.database.getReference("ventilador")

            database.get().addOnSuccessListener {
                Ventilador = it.value.toString()
            }
            if (Ventilador == "true") {

                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("ventilador")
                myRef.setValue(false)
                estadoVentiladorPedazo = "OFF"
                txtEstadoVentilador.text = estadoVentiladorPedazo
            } else {
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("ventilador")
                myRef.setValue(true)
                estadoVentiladorPedazo = "ON"
                txtEstadoVentilador.text = estadoVentiladorPedazo
            }
        }

        botonPersianaHabitacionSube.setOnClickListener() {
            if (estadoPersiana == false) {

                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("persianasube")
                estadoPersianaPedazo = "Arriba"
                txtEstadoPersiana.text = estadoPersianaPedazo
                myRef.setValue(true)
                estadoPersiana = true
            } else {
                val database = FirebaseDatabase.getInstance()
                val myRef = database.getReference("persianabaja")
                estadoPersianaPedazo = "Abajo"
                txtEstadoPersiana.text = estadoPersianaPedazo
                myRef.setValue(true)
                estadoPersiana = false
            }
        }



    }



    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProvider(this).get(HabitacionViewModel::class.java)
        // TODO: Use the ViewModel
    }

}