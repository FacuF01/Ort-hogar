package com.ignaciocanay.firebase.viewmodels

import androidx.lifecycle.ViewModel

class CocinaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}